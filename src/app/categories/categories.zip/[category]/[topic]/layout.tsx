// app/categories/[category]/[topic]/layout.tsx

import { ReactNode } from 'react';

interface LayoutProps {
  children: ReactNode;
  params: {
    category: string;
    topic: string;
  };
}

// This runs on the server at build time or during revalidation
export async function generateMetadata({ params }: LayoutProps) {
  const { category, topic } = params;

  try {
    const res = await fetch(
      `${process.env.NEXT_PUBLIC_API_URL}/meta/?page=${category}&category=${topic}`,
      { next: { revalidate: 60 } }
    );

    if (!res.ok) throw new Error(`Failed to fetch: ${res.status}`);
    const { title, description, keywords } = await res.json();

    return {
      title: title || 'Working Holiday Jobs New Zealand',
      description: description || 'Discover seasonal jobs and explore NZ.',
      keywords: keywords || 'New Zealand, jobs, working holiday, travel',
    };
  } catch (err) {
    console.error('Metadata API error:', err);
    return {
      title: 'Working Holiday Jobs New Zealand',
      description: 'Fallback: seasonal jobs, travel, NZ visa info.',
      keywords: 'New Zealand, jobs, visa, travel',
    };
  }
}

export default function CategoriesLayout({ children }: LayoutProps) {
  return <>{children}</>;
}

'use client';

import { useEffect, useState } from 'react';
import ToastViewer from '../../components/common/ToastViewer';

interface Props {
  category: string;
  topic: string;
  content: string;
}

export default function CategoriesMainContent({ category, topic, content }: Props) {

  console.log(content);
  const [loadedContent, setLoadedContent] = useState(content);

  useEffect(() => {
    setLoadedContent(content); // if topic/category changes
  }, [content]);

  return (
    <div className="min-h-[70vh] py-6 px-3">
      <ToastViewer key={`${category}-${topic}`} content={loadedContent} loading={!loadedContent} />
    </div>
  );
}
